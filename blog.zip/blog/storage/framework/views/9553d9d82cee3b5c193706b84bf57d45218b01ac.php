<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <?php echo $__env->yieldContent('title'); ?>;
</head>
<body>
    <?php echo $__env->yieldContent('content'); ?>;
</body>
</html>
<?php /**PATH C:\OpenServer\blog\resources\views/layouts/template1.blade.php ENDPATH**/ ?>