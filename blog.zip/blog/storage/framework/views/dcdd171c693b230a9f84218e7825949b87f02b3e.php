<?php $__env->startSection('title'); ?><title>Index</title><?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?><?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li>
        <a href="tasks/<?php echo e($task->id); ?>">
            <?php echo e($task->body); ?>

        </a>
    </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\blog\resources\views/index.blade.php ENDPATH**/ ?>