@extends('layouts.template1')

@section('title')
        <title>Show</title>
@endsection
@section('content')
    <h1>{{$task->body}}</h1>
@endsection

